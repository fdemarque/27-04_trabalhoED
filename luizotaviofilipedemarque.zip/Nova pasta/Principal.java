public class Principal {

    public static void main(String[] args) {
        Recursividade r = new Recursividade();
//         System.out.println(r.testesFatorial());
//         System.out.println(r.testesFibonacci());
//         System.out.println(r.testesMultiplicacao());
           System.out.println(r.divisao(70, 9));
           System.out.println(r.resto(70, 9));
           System.out.println(r.tamanho("tchubiraundaundaum"));
    }
}
